
name = "panelme"
api_id = 123456789
api_hash = ""
session_string = ""